# This is a sample Python script.
import time
from PyQt5 import uic, QtWidgets
import sys
from PyQt5 import QtCore
import check
import platform
import game
inc_array = ['\t', '\n', '\r', ' ', '!', '"', '#', '/', '\\']
key_array = ['\t', '\n', '\r', ' ', '!', '"', '#', '$', '%', '&', "'", '(',
             ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
             '8', '9', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`',
             'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
             'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
             'accept', 'add', 'alt', 'altleft', 'altright', 'apps', 'backspace',
             'browserback', 'browserfavorites', 'browserforward', 'browserhome',
             'browserrefresh', 'browsersearch', 'browserstop', 'capslock', 'clear',
             'convert', 'ctrl', 'ctrlleft', 'ctrlright', 'decimal', 'del', 'delete',
             'divide', 'down', 'end', 'enter', 'esc', 'escape', 'execute', 'f1', 'f10',
             'f11', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18', 'f19', 'f2', 'f20',
             'f21', 'f22', 'f23', 'f24', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9',
             'final', 'fn', 'hanguel', 'hangul', 'hanja', 'help', 'home', 'insert', 'junja',
             'kana', 'kanji', 'launchapp1', 'launchapp2', 'launchmail',
             'launchmediaselect', 'left', 'modechange', 'multiply', 'nexttrack',
             'nonconvert', 'num0', 'num1', 'num2', 'num3', 'num4', 'num5', 'num6',
             'num7', 'num8', 'num9', 'numlock', 'pagedown', 'pageup', 'pause', 'pgdn',
             'pgup', 'playpause', 'prevtrack', 'print', 'printscreen', 'prntscrn',
             'prtsc', 'prtscr', 'return', 'right', 'scrolllock', 'select', 'separator',
             'shift', 'shiftleft', 'shiftright', 'sleep', 'space', 'stop', 'subtract', 'tab',
             'up', 'volumedown', 'volumemute', 'volumeup', 'win', 'winleft', 'winright', 'yen',
             'command', 'option', 'optionleft', 'optionright']


Form, _ = uic.loadUiType('interface.ui')
Form2, _ =uic.loadUiType('fromtokey.ui')


def timer(f):
    def tmp(*args, **kwargs):
        t = time.time()
        res = f(*args, **kwargs)
        print("Время выполнения функции: %f" % (time.time() - t))
        return res

    return tmp


class Ui(QtWidgets.QMainWindow, Form):
    def __init__(self):
        super(Ui, self).__init__()
        self.setupUi(self)
        self.setWindowFlags(QtCore.Qt.WindowStaysOnTopHint)

        self.thread = QtCore.QThread()
        self.game = game.Game()
        self.game.moveToThread(self.thread)
        self.thread.started.connect(self.game.run)
        self.thread.start()

        self.start.clicked.connect(self.StartPressed)
        self.stop.clicked.connect(self.StopPressed)
        self.settings.clicked.connect(self.ConfirmSettings)

    def keyPressEvent(self, e):
        y = e.key()
        if y == QtCore.Qt.Key_Escape:
            self.close()

        if y < 2000:
            x = chr(y).lower()

            if x == 'z' or x == 'я':
                self.start.setEnabled(True)
                self.stop.setEnabled(False)
                self.game.stop = True

            if x == 'ч' or x == 'x':
                self.game.stop = False
                self.stop.setEnabled(True)
                self.start.setEnabled(False)

    def StartPressed(self):
        try:
            self.stop.setEnabled(True)
            self.start.setEnabled(False)
            self.game.stop = False
        except:
            print('ошибка старта')

    def StopPressed(self):
        try:
            self.start.setEnabled(True)
            self.stop.setEnabled(False)
            self.game.stop = True
        except:
            print('error stop')

    def ConfirmSettings(self):
        self.game.hook_rad = self.spinBox.value()
        self.game.eat = self.eat.isChecked()
        self.game.bait = self.bait.isChecked()
        self.game.wait_eat = self.wait_eat.value()
        self.game.wait_bait = self.wait_bait.value()
        self.game.i_click = self.SpinBox_hook.value()
        self.game.time_bait = self.spinBox_2.value()
        self.game.percent_find = self.SpinBox_percent_find.value()

        self.lineEdit.setText('')
        if self.key_bait.toPlainText().lower() in key_array:
            self.game.key_bait = self.key_bait.toPlainText().lower()
        else:
            if self.key_bait.toPlainText().lower() != '':

                self.lineEdit.setText(f'{self.key_bait.toPlainText()} не может быть клавишей; {self.lineEdit.text()}')

        if self.key_eat.toPlainText().lower() in key_array:
            self.game.key_eating = self.key_eat.toPlainText().lower()
        else:
            if self.key_eat.toPlainText().lower():
                self.lineEdit.setText(f'{self.key_eat.toPlainText()} не может быть клавишей; {self.lineEdit.text()}')


class Ui2(QtWidgets.QMainWindow, Form2):
    def __init__(self):
        super(Ui2, self).__init__()
        self.setupUi(self)
        self.send.setEnabled(False)
        self.key = '/'
        self.goto = False
        self.platform = platform.platform() + platform.processor()
        self.Ui = Ui()
        self.send.clicked.connect(self.check)
        self.Accept.clicked.connect(self.Checkontrue)

    def check(self):
        if self.goto:
            self.Ui.show()
            self.close()

    def rev_cod(self):
        x = ''
        y = ''
        k=True
        for i in self.platform:
            if k:
                x += chr(ord(i) + 2)
                k=False
            else:
                x += chr(ord(i) - 2)
                k=True
        for i in x:
            if i not in inc_array:
                y += i



        return y[::-1]

    def Checkontrue(self):
        time.sleep(1)
        self.key = self.keyform.toPlainText()

        if self.bool_check_string():
            if self.get_check_string().find(self.rev_cod()) == -1:
                if len(self.get_check_string()) <= 16:
                    self.send.setEnabled(False)
                    self.lineEdit.setText(self.rev_cod())
                else:
                    self.lineEdit.setText('Ключ для этого устройства не активирован')
            else:

                self.lineEdit.setText('Ключ доступен')
                self.goto = True
                self.send.setEnabled(True)

        else:
            self.lineEdit.setText('Неверный ключ')
            self.send.setEnabled(False)

    def get_check_string(self):
        text = check.parse()
        for i in text:

            if self.key in i:

                return i

        return '!!'

    def bool_check_string(self):
        if len(self.key) != 15:
            return False
        text = check.parse()
        bool = False

        for i in text:
            if self.key in i:
                bool = True
                break
            else:
                bool = False

        return bool

def ma():
    app = QtWidgets.QApplication(sys.argv)
    z = Ui2()
    z.show()
    sys.exit(app.exec_())





