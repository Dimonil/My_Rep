# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

url ="https://github.com/Dimonil/My_Rep/blob/main/this.txt"
ua = UserAgent()
headers = {'user-agent': f'{ua.chrome}'}


def get_html(url, params=None):
    responce = requests.get(url, headers=headers, params=params)
    return responce


def get_content(html):
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('tr')
    string = []
    for item in items:
        string.append({
            'title': item.find('td', class_="blob-code blob-code-inner js-file-line").get_text()
        })
    array = []
    for i in string:
        array.append(*i.values())

    return array


def parse():
    html = get_html(url)
    if (html.status_code == 200):
        a = get_content(html.text)
        return a
    else:
        print('Error')

